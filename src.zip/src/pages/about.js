import React from 'react';
import './About.css';
import profilePic from '../assets/picture.jpg'; 

const About = () => {
  return (
    <section id="about" className="about-section">
      <h2>About Me</h2>
      <div className="about-content">
        <img src={profilePic} alt="Profile" className="profile-pic" />
        <p>
          I'm Atchaya S, a second-year B.Tech student majoring in AI & Data Science at Sri Eshwar College of Engineering.
          My passion for technology, particularly in artificial intelligence and machine learning, drives me to continuously learn and explore new advancements in the field.
          I enjoy building applications that solve real-world problems, and I'm constantly improving my skills to make a positive impact.
        </p>
      </div>
    </section>
  );
};

export default About;
