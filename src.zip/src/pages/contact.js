import React, { useState } from 'react';
import './Contact.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Integrate form submission logic here, like using EmailJS or a custom API
    console.log(formData);
  };

  return (
    <section id="contact" className="contact-section">
      <h2>Contact Me</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Name</label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <label htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <label htmlFor="message">Message</label>
        <textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          required
        ></textarea>
        <button type="submit">Send Message</button>
      </form>

      {/* Contact Information Section */}
      <div className="contact-info">
        <h3>Connect with Me</h3>
        <ul>
          <li>
            <a href="mailto:atchayaselvaraj2006@gmail.com" className="contact-link">
              📧 Email: atchayaselvaraj2006@gmail.com
            </a>
          </li>
          <li>
            <a href="https://www.linkedin.com/in/atchaya-s-ai-ds-bb700a2a8/" target="_blank" rel="noopener noreferrer" className="contact-link">
              💼 LinkedIn: your-profile
            </a>
          </li>
          <li>
            <a href="tel:+1234567890" className="contact-link">
              📞 Phone: +91 9876543210
            </a>
          </li>
        </ul>
      </div>
    </section>
  );
};

export default Contact;
