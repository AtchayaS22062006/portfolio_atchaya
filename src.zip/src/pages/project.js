import React from 'react';
import './Projects.css';

const Projects = () => {
  return (
    <section id="projects" className="projects-section">
      <h2>Projects</h2>
      <div className="project-cards">
        <div className="project-card">
          <h3>MEDHUB: Telemedicine Application</h3>
          <p>A telemedicine platform that enables virtual communication between doctors and patients. The app includes video consultations, appointment scheduling, and medical record management.</p>
          <ul>
            <li>Technologies: React, Node.js, Express, MongoDB, WebRTC</li>
            <li>Project Link: <a href="https://github.com/yourusername/medhub" target="_blank" rel="noopener noreferrer">GitHub</a></li>
            <li>Live Demo: <a href="https://medhub-demo.com" target="_blank" rel="noopener noreferrer">Demo</a></li>
          </ul>
        </div>

        <div className="project-card">
          <h3>SKILLSYNC: E-Learning Website</h3>
          <p>SKILLSYNC is an e-learning platform designed to help students enhance their skills in various domains. It features course management, quizzes, and progress tracking.</p>
          <ul>
            <li>Technologies: React, Node.js, MongoDB, Firebase</li>
            <li>Project Link: <a href="https://github.com/yourusername/skillsync" target="_blank" rel="noopener noreferrer">GitHub</a></li>
            <li>Live Demo: <a href="https://skillsync-demo.com" target="_blank" rel="noopener noreferrer">Demo</a></li>
          </ul>
        </div>

        <div className="project-card">
          <h3>Emotion Detection: E-Learning Website</h3>
          <p>Emotion Detection uses computer vision techniques to analyze facial expressions and detect emotions. It is integrated into an e-learning platform to create personalized learning experiences.</p>
          <ul>
            <li>Technologies: Python, OpenCV, React, Flask</li>
            <li>Project Link: <a href="https://github.com/yourusername/emotion-detection" target="_blank" rel="noopener noreferrer">GitHub</a></li>
            <li>Live Demo: <a href="https://emotion-detection-demo.com" target="_blank" rel="noopener noreferrer">Demo</a></li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default Projects;
