import React from "react";

function Home() {
  return (
    <section id="home" className="home">
      <div className="home-content">
        <h1>Welcome to My Portfolio</h1>
        <p>Hi, I'm Atchaya S, a B.Tech (AI & DS) student with a passion for programming and tech. I specialize in building innovative applications, particularly those focused on artificial intelligence and machine learning.</p>
        <p>I believe in the power of technology to solve real-world problems, and I'm constantly improving my skills to keep up with industry trends. Explore my portfolio to see some of the projects I've worked on!</p>
      </div>
    </section>
  );
}

export default Home;
