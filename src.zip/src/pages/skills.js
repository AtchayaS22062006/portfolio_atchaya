import React from 'react';
import './skills.css'; // Importing Skills.css for this section

const Skills = () => {
  return (
    <section id="skills" className="skills-section">
      <h2>Skills & Expertise</h2>
      <ul>
        <li><h5>Languages:</h5> C, Python, Java, JavaScript, C++, HTML5, CSS, ReactJS</li>
        <li><h5>Core:</h5> Data Structures, Algorithms, Object-Oriented Programming</li>
        <li><h5>Frameworks & Libraries:</h5> Numpy, Pandas, OpenCV, Flask</li>
        <li><h5>Tools: </h5>VSCode, GitHub, Figma, Canva, Blender, Arduino, LabView</li>
      </ul>
      
      <h2>Achievements</h2>
      <ul>
        <li>Winner of AI Hackathon, 2024</li>
        <li>Secured 1st place in AI Programming Challenge, 2023</li>
        <li>Top 10 finalist in SHR National Coding Contest, 2024</li>
        <li>Completed a Data Science internship at FAN Company, 2023</li>
        <li>Contributed to several open-source AI projects on GitHub</li>
      </ul>
      
      <p>
        Over the past year, I've participated in various hackathons, secured positions, and developed several projects, 
        which are listed in the "Projects" section. My future goals include mastering AI and contributing to meaningful open-source projects.
      </p>
    </section>
  );
};

export default Skills;
