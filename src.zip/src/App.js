import React from "react";
import Navbar from "./components/Navbar";
import Home from "./pages/home";
import About from "./pages/about";
import Projects from "./pages/project";
import Contact from "./pages/contact";
import Skills from "./pages/skills";
import './App.css';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Home />
      <About />
      <Skills />
      <Projects />
      <Contact />
    </div>
  );
}

export default App;
